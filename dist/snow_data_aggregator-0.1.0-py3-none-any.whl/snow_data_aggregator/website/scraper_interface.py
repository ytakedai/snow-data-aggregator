from abc import ABC, abstractmethod

class ScraperInterface(ABC):

    @abstractmethod
    def get_snowfall_12(self) -> int:
        pass

    @abstractmethod
    def get_snowfall_24(self) -> int:
        pass

    @abstractmethod
    def get_forecast(self) -> str:
        pass