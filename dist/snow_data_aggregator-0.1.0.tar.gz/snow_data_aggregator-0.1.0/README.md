# README
This project is meant to help me learn Python development practices, while developing a service that provides snowfall data to 
users in one location.